// middleware/errorMiddleware.js
const errorHandler = (err, req, res, next) => {
    let statusCode = res.statusCode === 200 ? 500 : res.statusCode; // Default to 500 if status code is not set
    let message = err.message || 'Internal Server Error';
  
    // Log the error for debugging (optional)
    console.error(`Error: ${err.message}\nStack: ${err.stack}`);
  
    // Mongoose bad ObjectId Error
    if (err.name === 'CastError' && err.kind === 'ObjectId') {
        statusCode = 404; // Or 400 Bad Request
        message = `Resource not found with id of ${err.value}`;
    }
  
    // Mongoose duplicate key Error (e.g., unique email/username)
    if (err.code === 11000) {
        statusCode = 400;
        const field = Object.keys(err.keyValue)[0];
        message = `Duplicate field value entered for ${field}. Please use another value.`;
    }
  
    // Mongoose validation Error
    if (err.name === 'ValidationError') {
        statusCode = 400;
        // Combine multiple validation errors into one message string
        message = Object.values(err.errors).map(val => val.message).join(', ');
    }
  
     // JWT specific errors (can be added if needed for more granular control)
    // if (err.name === 'JsonWebTokenError') {
    //     statusCode = 401;
    //     message = 'Invalid token';
    // }
    // if (err.name === 'TokenExpiredError') {
    //     statusCode = 401;
    //     message = 'Token expired';
    // }
  
  
    res.status(statusCode).json({
      success: false,
      message: message,
      // Optionally include stack trace in development mode
      // stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
  };
  
  module.exports = errorHandler;