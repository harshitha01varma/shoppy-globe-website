// models/Cart.js




const mongoose = require('mongoose');

// Single product inside cart
const CartItemSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
    min: [1, 'Quantity must be at least 1'],
    default: 1,
  }
}, { _id: true }); // keep _id for cart item (important for delete/update)

const CartSchema = new mongoose.Schema({
  userId: {  // 👈 match with your controller (req.user.id)
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  products: {   // 👈 match with your controller (cart.products)
    type: [CartItemSchema],
    default: [] // 👈 important to avoid "undefined"
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  }
});

// Update timestamp before saving
CartSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Cart', CartSchema);
