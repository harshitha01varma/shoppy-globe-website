// models/Product.js
const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add a product name'],
    trim: true,
  },
  description: {
    type: String,
    required: [true, 'Please add a product description'],
  },
  price: {
    type: Number,
    required: [true, 'Please add a product price'],
    min: [0, 'Price cannot be negative'],
  },
  stockQuantity: {
    type: Number,
    required: [true, 'Please add stock quantity'],
    min: [0, 'Stock quantity cannot be negative'],
    default: 0,
  },
  imageUrl: {
    type: String,
    default: '/images/default-product.png'
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Product', ProductSchema);







// // models/Product.js
// const mongoose = require('mongoose');
// const express = require('express');
// const Product = require('../models/Product');
// const router = express.Router();



// const ProductSchema = new mongoose.Schema({
//   name: {
//     type: String,
//     required: [true, 'Please add a product name'],
//     trim: true,
//   },
//   description: {
//     type: String,
//     required: [true, 'Please add a product description'],
//   },
//   price: {
//     type: Number,
//     required: [true, 'Please add a product price'],
//     min: [0, 'Price cannot be negative'],
//   },
//   stockQuantity: {
//     type: Number,
//     required: [true, 'Please add stock quantity'],
//     min: [0, 'Stock quantity cannot be negative'],
//     default: 0,
//   },
//   imageUrl: { // Added for better frontend display
//       type: String,
//       default: '/images/default-product.png' // Provide a default image path
//   },
//   createdAt: {
//     type: Date,
//     default: Date.now,
//   },
// });

// router.get('/', async (req, res) => {
//   try {
//     const products = await Product.find();
//     res.json(products);
//   } catch (err) {
//     res.status(500).json({ message: "Error fetching products" });
//   }
// });

// module.exports = router;
// module.exports = mongoose.model('Product', ProductSchema);