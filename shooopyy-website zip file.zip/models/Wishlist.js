// models/Wishlist.js
const mongoose = require('mongoose');

const WishlistSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        unique: true, // Each user has one wishlist
    },
    products: [{ // Store only product IDs
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true,
    }],
    updatedAt: {
        type: Date,
        default: Date.now,
    },
});

// Update `updatedAt` timestamp whenever the wishlist is saved
WishlistSchema.pre('save', function (next) {
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Wishlist', WishlistSchema);
