// Import express and create a router instance
const express = require('express');
const router = express.Router();
const { deleteCartItem } = require('../controllers/cartController');
// Import controller functions for cart operations
const {
  addToCart,
  getCartItems,
  updateCartItem,
  
} = require('../controllers/cartController');
const { protect } = require('../middleware/authMiddleware');
// Import authentication middleware to protect routes

// @route   POST /api/cart
// @desc    Add a product to the cart
// @access  Private (requires authentication)
router.post('/', protect, addToCart);
// @route   GET /api/cart
// @desc    Get all cart items for the logged-in user
// @access  Private (requires authentication)
router.get('/', protect, getCartItems);
// @route   PUT /api/cart/:id
// @desc    Update quantity of a specific cart item
// @access  Private (requires authentication)

router.put('/:id', protect, updateCartItem);


// @route   DELETE /api/cart/item/:itemId
// @desc    Remove a specific item from the cart
router.delete('/item/:itemId', deleteCartItem);
// Export the router to be used in the app

module.exports = router;
















