// routes/wishlistRoutes.js
const express = require('express');
const {
    getWishlist,
    addItemToWishlist,
    removeItemFromWishlist,
} = require('../controllers/wishlistController');
const { protect } = require('../middleware/authMiddleware'); // Protect all wishlist routes

const router = express.Router();

// Apply protect middleware to all routes in this file
router.use(protect);

router.route('/')
    .get(getWishlist)          // GET /api/wishlist - Get user's wishlist
    .post(addItemToWishlist);  // POST /api/wishlist - Add item to wishlist

router.route('/:productId')
    .delete(removeItemFromWishlist); // DELETE /api/wishlist/:productId - Remove item

module.exports = router;