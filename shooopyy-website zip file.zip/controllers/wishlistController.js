// controllers/wishlistController.js
const Wishlist = require('../models/Wishlist');
const Product = require('../models/Product');

// Helper to get or create wishlist
const getOrCreateWishlist = async (userId) => {
    let wishlist = await Wishlist.findOne({ user: userId });
    if (!wishlist) {
        wishlist = await Wishlist.create({ user: userId, products: [] });
    }
    return wishlist;
};

// @desc    Get user's wishlist
// @route   GET /api/wishlist
// @access  Private
exports.getWishlist = async (req, res, next) => {
    try {
        const wishlist = await Wishlist.findOne({ user: req.user._id }).populate({
            path: 'products', // Populate the product details
            select: 'name price imageUrl' // Select specific fields
        });

        if (!wishlist) {
            return res.json({ user: req.user._id, products: [], message: "Wishlist is empty" });
        }

        res.json(wishlist);
    } catch (error) {
        next(error);
    }
};

// @desc    Add item to wishlist
// @route   POST /api/wishlist
// @access  Private
exports.addItemToWishlist = async (req, res, next) => {
    const { productId } = req.body;
    const userId = req.user._id;

    if (!productId) {
        res.status(400);
        return next(new Error('Product ID is required'));
    }

    try {
        // Check if product exists
        const productExists = await Product.findById(productId);
        if (!productExists) {
            res.status(404);
            return next(new Error('Product not found'));
        }

        const wishlist = await getOrCreateWishlist(userId);

        // Check if product already in wishlist
        const alreadyExists = wishlist.products.some(pId => pId.toString() === productId);

        if (alreadyExists) {
            res.status(400);
            return next(new Error('Product already in wishlist'));
            // Or just return the current wishlist:
            // await wishlist.populate({path: 'products', select: 'name price imageUrl'});
            // return res.status(200).json(wishlist);
        }

        // Add product ID to the list
        wishlist.products.push(productId);
        const updatedWishlist = await wishlist.save();

        // Populate for response
        await updatedWishlist.populate({
            path: 'products',
            select: 'name price imageUrl'
        });

        res.status(201).json({ // 201 Created or 200 OK if item was added
            _id: updatedWishlist._id,
            user: updatedWishlist.user,
            products: updatedWishlist.products,
            updatedAt: updatedWishlist.updatedAt,
            message: "Item added to wishlist"
        });

    } catch (error) {
        next(error);
    }
};

// @desc    Remove item from wishlist
// @route   DELETE /api/wishlist/:productId
// @access  Private
exports.removeItemFromWishlist = async (req, res, next) => {
    const { productId } = req.params;
    const userId = req.user._id;

    try {
        const wishlist = await Wishlist.findOne({ user: userId });

        if (!wishlist) {
            res.status(404);
            return next(new Error('Wishlist not found'));
        }

        const initialLength = wishlist.products.length;
        // Remove the product ID from the array
        wishlist.products = wishlist.products.filter(pId => pId.toString() !== productId);

        if (wishlist.products.length === initialLength) {
             res.status(404);
             return next(new Error('Item not found in wishlist'));
        }

        const updatedWishlist = await wishlist.save();

        // Populate for response
         await updatedWishlist.populate({
            path: 'products',
            select: 'name price imageUrl'
        });

        res.json({
            _id: updatedWishlist._id,
            user: updatedWishlist.user,
            products: updatedWishlist.products,
            updatedAt: updatedWishlist.updatedAt,
            message: "Item removed from wishlist"
        });

    } catch (error) {
        next(error);
    }
};
