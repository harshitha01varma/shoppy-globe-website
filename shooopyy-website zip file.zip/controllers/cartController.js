const Cart = require('../models/Cart');
const Product = require('../models/Product');

/**
 * @desc    Add item(s) to cart or update quantity if exists.
 *          Expects req.body.cartItems = [{ productId: '...', quantity: X }]
 * @route   POST /api/cart
 * @access  Private (Requires Authentication)
 */
exports.addToCart = async (req, res) => {
  try {
    // 1. Check for authenticated user
    if (!req.user || !req.user.id) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    const userId = req.user.id;

    // 2. Get and validate input array
    const { cartItems } = req.body;
    if (!Array.isArray(cartItems) || cartItems.length === 0) {
      return res.status(400).json({ success: false, message: 'cartItems must be a non-empty array' });
    }

    // 3. Find user's cart or create a new one
    let cart = await Cart.findOne({ userId: userId });
    if (!cart) {
      cart = new Cart({ userId: userId, products: [] });
    }

    // 4. Process each item in the input array
    const notFoundProducts = [];
    const invalidItems = [];

    for (const item of cartItems) {
      const { productId, quantity } = item;

      // Basic validation for each item
      if (!productId || typeof quantity !== 'number' || quantity <= 0 || !Number.isInteger(quantity)) {
        invalidItems.push(item);
        console.warn(`Skipping invalid cart item data: ${JSON.stringify(item)} for user ${userId}`);
        continue; // Skip this invalid item
      }

      // Check if product exists
      const product = await Product.findById(productId);
      if (!product) {
        notFoundProducts.push(productId);
        console.warn(`Product not found, skipping: ${productId} for user ${userId}`);
        continue; // Skip non-existent products
      }

      // Find if item already exists in cart
      const itemIndex = cart.products.findIndex(p => p.productId.equals(productId));

      if (itemIndex > -1) {
        // Update quantity
        cart.products[itemIndex].quantity += quantity;
      } else {
        // Add new item
        cart.products.push({ productId, quantity });
      }
    } // End of for loop

    // 5. Save the cart
    const updatedCart = await cart.save();

    // 6. Populate product details for the response
    await updatedCart.populate('products.productId'); // Populate with Product details

    // 7. Send response
    let message = 'Cart updated successfully';
    if (notFoundProducts.length > 0 || invalidItems.length > 0) {
        message += '. Some items were skipped due to errors (product not found or invalid data).';
    }

    res.status(200).json({
        success: true,
        message: message,
        cart: updatedCart,
        skipped: { notFoundProducts, invalidItems } // Optionally report skipped items
    });

  } catch (error) {
    console.error('Error in addToCart:', error);
    res.status(500).json({ success: false, message: 'Server error while adding to cart' });
  }
};

/**
 * @desc    Get all items in the user's cart
 * @route   GET /api/cart
 * @access  Private
 */
exports.getCartItems = async (req, res) => {
  try {
    // 1. Check for authenticated user
    if (!req.user || !req.user.id) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    const userId = req.user.id;

    // 2. Find cart and populate product details
    const cart = await Cart.findOne({ userId: userId }).populate({
        path: 'products.productId', // Populate the productId field within the products array
        model: 'Product' // Explicitly specify the model name (good practice)
        // select: 'name price image' // Optional: select only specific fields from Product
    });

    if (!cart) {
      // It's okay if a user has no cart yet, return an empty structure
      return res.status(200).json({
          success: true,
          message: 'Cart is empty or not found',
          cart: { userId: userId, products: [], _id: null } // Send a consistent empty cart structure
      });
    }

    // 3. Return the cart
    res.status(200).json({ success: true, message: 'Cart retrieved successfully', cart });

  } catch (error) {
    console.error('Error in getCartItems:', error);
    res.status(500).json({ success: false, message: 'Server Error getting cart items' });
  }
};

/**
 * @desc    Update the quantity of a specific item in the cart
 * @route   PATCH /api/cart/item/:itemId
 * @access  Private
 */
exports.updateCartItem = async (req, res) => {
  try {
    // 1. Check for authenticated user
    if (!req.user || !req.user.id) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    const userId = req.user.id;
    const cartItemId = req.params.itemId; // Use itemId consistently

    // 2. Validate new quantity
    const { quantity } = req.body;
    if (typeof quantity !== 'number' || quantity <= 0 || !Number.isInteger(quantity)) {
        return res.status(400).json({ success: false, message: 'Invalid quantity provided. Must be a positive integer.' });
    }

    // 3. Find the cart
    let cart = await Cart.findOne({ userId: userId });
    if (!cart) {
      return res.status(404).json({ success: false, message: 'Cart not found' });
    }

    // 4. Find the specific item within the cart's products array
    // Mongoose's .id() method finds subdocuments by their _id
    const item = cart.products.id(cartItemId);
    if (!item) {
      return res.status(404).json({ success: false, message: 'Item not found in cart' });
    }

    // 5. Update quantity and save
    item.quantity = quantity;
    const updatedCart = await cart.save();

    // 6. Populate for response
    await updatedCart.populate('products.productId');

    // 7. Respond
    res.status(200).json({ success: true, message: 'Cart item updated', cart: updatedCart });

  } catch (error) {
    console.error('Error in updateCartItem:', error);
    res.status(500).json({ success: false, message: 'Server Error updating cart item' });
  }
};

/**
 * @desc    Delete a specific item from the user's cart
 * @route   DELETE /api/cart/item/:itemId
 * @access  Private
 */
exports.deleteCartItem = async (req, res) => {
  try {
    // 1. Check for authenticated user
    if (!req.user || !req.user.id) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    const userId = req.user.id;
    const cartItemId = req.params.itemId; // Get item's subdocument ID from URL parameter

    // 2. Find the user's cart
    const cart = await Cart.findOne({ userId: userId });

    if (!cart) {
      return res.status(404).json({ success: false, message: 'Cart not found' });
    }

    // 3. Find the index of the product *subdocument* using its _id
    const itemIndex = cart.products.findIndex(
      (item) => item._id.toString() === cartItemId
    );

    if (itemIndex === -1) {
      return res.status(404).json({ success: false, message: 'Item not found in cart' });
    }

    // 4. Remove the item from the products array
    cart.products.splice(itemIndex, 1);
    const updatedCart = await cart.save(); // Save the updated cart

    // 5. Populate for response
    await updatedCart.populate('products.productId');

    // 6. Send success response
    res.status(200).json({ success: true, message: 'Item removed successfully', cart: updatedCart });

  } catch (error) {
    console.error('Error deleting cart item:', error);
    res.status(500).json({ success: false, message: 'Server error while deleting item' });
  }
};


























// const Cart = require('../models/Cart');
// // const Product = require('../models/Product');



// const product = await Product.findById(productId);
// // Add product to cart
// exports.addToCart = async (req, res) => {
//   const { cartItems } = req.body; // expecting an array of { productId, quantity }
  
//   if (!Array.isArray(cartItems)) {
//     return res.status(400).json({ message: 'cartItems must be an array' });
//   }

//   let cart = await Cart.findOne({ userId: req.user.id });
//   if (!cart) {
//     cart = new Cart({ userId: req.user.id, products: [] });
//   }

//   for (const item of cartItems) {
//     const { productId, quantity } = item;

//     const product = await Product.findById(productId);
//     if (!product) {
//       return res.status(404).json({ message: `Product not found: ${productId}` });
//     }

//     const itemIndex = cart.products.findIndex(p => p.productId.equals(productId));

//     if (itemIndex > -1) {
//       cart.products[itemIndex].quantity += quantity;
//     } else {
//       cart.products.push({ productId, quantity });
//     }
//   }

//   await cart.save();
//   res.status(201).json(cart);
// };

 


// // Get all cart items
// exports.getCartItems = async (req, res) => {
//   try {
//     const cart = await Cart.findOne({ userId: req.user.id }).populate('products.productId');
    
//     if (!cart) return res.status(404).json({ message: 'Cart not found' });
    
//     res.json(cart);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Server Error' });
//   }
// };

// // Update cart item
// exports.updateCartItem = async (req, res) => {
//   try {
//     const { quantity } = req.body;
//     let cart = await Cart.findOne({ userId: req.user.id });

//     if (!cart) return res.status(404).json({ message: 'Cart not found' });

//     const item = cart.products.id(req.params.id);
//     if (!item) return res.status(404).json({ message: 'Item not found' });

//     item.quantity = quantity;
//     await cart.save();
//     res.json(cart);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Server Error' });
//   }
// };




// // Delete a specific product from the user's cart
// exports.deleteCartItem = async (req, res) => {
//   try {
//     const userId = req.user.id; // from your auth middleware
//     const cartItemId = req.params.itemId;

//     const cart = await Cart.findOne({ user: userId });

//     if (!cart) {
//       return res.status(404).json({ success: false, message: 'Cart not found' });
//     }

//     const itemIndex = cart.products.findIndex(
//       (item) => item._id.toString() === cartItemId
//     );

//     if (itemIndex === -1) {
//       return res.status(404).json({ success: false, message: 'Item not found' });
//     }

//     cart.products.splice(itemIndex, 1); // remove the product
//     await cart.save();

//     res.status(200).json({ success: true, message: 'Item removed successfully', cart });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };
