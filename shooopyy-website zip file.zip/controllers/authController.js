// controllers/authController.js
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');

dotenv.config();

// Generate JWT Token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d', // Token expires in 30 days
  });
};

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
exports.registerUser = async (req, res, next) => {
  const { username, email, password } = req.body;

  // Basic validation
  if (!username || !email || !password) {
      res.status(400); // Bad Request
      return next(new Error('Please provide username, email, and password'));
  }

  try {
    // Check if user already exists
    const userExists = await User.findOne({ $or: [{ email }, { username }] });
    if (userExists) {
      res.status(400);
      return next(new Error(`User with that ${userExists.email === email ? 'email' : 'username'} already exists`));
    }

    // Create user (password hashing is handled by pre-save hook in User model)
    const user = await User.create({
      username,
      email,
      password,
    });

    // If user created successfully, send back user info and token
    if (user) {
      res.status(201).json({ // 201 Created
        _id: user._id,
        username: user.username,
        email: user.email,
        token: generateToken(user._id),
        message: "Registration successful"
      });
    } else {
      res.status(400); // Should have been caught by validation or DB error
      return next(new Error('Invalid user data'));
    }
  } catch (error) {
    next(error); // Pass error to the central error handler
  }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
exports.loginUser = async (req, res, next) => {
  const { email, password } = req.body;

  // Basic validation
  if (!email || !password) {
      res.status(400);
      return next(new Error('Please provide email and password'));
  }

  try {
    // Find user by email (include password for comparison)
    const user = await User.findOne({ email }).select('+password');

    // Check if user exists and password matches
    if (user && (await user.matchPassword(password))) {
      res.json({
        _id: user._id,
        username: user.username,
        email: user.email,
        token: generateToken(user._id),
        message: "Login successful"
      });
    } else {
      res.status(401); // Unauthorized
      return next(new Error('Invalid email or password'));
    }
  } catch (error) {
    next(error);
  }
};

// @desc    Get user profile (Example of a protected route)
// @route   GET /api/auth/profile
// @access  Private
exports.getUserProfile = async (req, res, next) => {
    // req.user is attached by the protect middleware
    // We find the user again in case details changed slightly, though req.user is usually sufficient
    try {
        const user = await User.findById(req.user._id); // req.user comes from protect middleware
        if (user) {
            res.json({
                _id: user._id,
                username: user.username,
                email: user.email,
                createdAt: user.createdAt
            });
        } else {
             res.status(404);
             next(new Error('User not found'));
        }
    } catch (error) {
        next(error);
    }
};