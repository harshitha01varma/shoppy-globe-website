const mongoose = require('mongoose');
const Product = require('./models/Product'); // adjust path if needed
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB connected for seeding...');
    return Product.insertMany([
      {
        name: 'iPhone 15',
        price: 999,
        description: 'Latest Apple iPhone with A16 Bionic chip',
      },
      {
        name: 'Samsung Galaxy S24',
        price: 899,
        description: 'Flagship Samsung phone with powerful camera',
      },
    
    ]);
  })
  .then(() => {
    console.log('Sample products inserted ');
    process.exit();
  })
  .catch(err => {
    console.error('Error seeding products:', err);
    process.exit(1);
  });
